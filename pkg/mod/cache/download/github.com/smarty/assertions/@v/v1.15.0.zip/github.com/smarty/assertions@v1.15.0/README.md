#### SMARTY DISCLAIMER: Subject to the terms of the associated license agreement, this software is freely available for your use. This software is FREE, AS IN PUPPIES, and is a gift. Enjoy your new responsibility. This means that while we may consider enhancement requests, we may or may not choose to entertain requests at our sole and absolute discretion.

[![Build Status](https://travis-ci.org/smarty/assertions.svg?branch=master)](https://travis-ci.org/smarty/assertions)
[![Code Coverage](https://codecov.io/gh/smarty/assertions/branch/master/graph/badge.svg)](https://codecov.io/gh/smarty/assertions)
[![Go Report Card](https://goreportcard.com/badge/github.com/smarty/assertions)](https://goreportcard.com/report/github.com/smarty/assertions)
[![GoDoc](https://godoc.org/github.com/smarty/assertions?status.svg)](http://godoc.org/github.com/smarty/assertions)
