// Package examples contains, well, examples of how to use goconvey to
// specify behavior of a system under test. It contains a well-known example
// by Robert C. Martin called "Bowling Game Kata" as well as another very
// trivial example that demonstrates Reset() and some of the assertions.
package examples
